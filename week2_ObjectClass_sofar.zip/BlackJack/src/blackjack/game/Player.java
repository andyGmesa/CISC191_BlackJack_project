/**
* Lead Author(s):
* @author 0909g; student ID
* @author Full name; student ID
* <<Add additional lead authors here>>
*
* Other Contributors:
* Full name; student ID or contact information if not in class
* <<Add additional contributors (mentors, tutors, friends) here, with contact information>>
*
* References:
* Morelli, R., & Walde, R. (2016).
* Java, Java, Java: Object-Oriented Problem Solving
* https://open.umn.edu/opentextbooks/textbooks/java-java-java-object-oriented-problem-solving
*
* <<Add more references here>>
*
* Version: 2025-11-01
*/
package blackjack.game;

import edu.sdmesa.cisc191.Card;
import edu.sdmesa.cisc191.Deck;
import java.util.ArrayList;
/**
 * Purpose: The reponsibility of Player is ...
 *
 * Player is-a ...
 * Player is ...
 */
public class Player
{
	private ArrayList<Card> hand;
	int handSum;
	private ArrayList<Card> splitHand;
	int splitHandSum;
	
	
	public Player(Card firstCard, Card secondCard)
	{
		hitFirstHand(firstCard);
		hitFirstHand(secondCard);
	}
	
	public void hitFirstHand(Card drawnCard)
	{
		hand.add(drawnCard);
		handSum += drawnCard.getNumber();
	}
	
	public void hitSplitHand(Card drawnCard)
	{
		splitHand.add(drawnCard);
		splitHandSum += drawnCard.getNumber();
	}
	
	public void Split()
	{
		Card popped = hand.removeLast();
		handSum -= popped.getNumber();
		
		hitSplitHand(popped);
	}
}
