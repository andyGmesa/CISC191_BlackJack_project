/**
 * Lead Author(s):
 * 
 * @author Andy Garcia; 5550315182
 *
 *
 *         Other Contributors:
 *         Full name; student ID or contact information if not in class
 *         <<Add additional contributors (mentors, tutors, friends) here, with
 *         contact information>>
 *
 *
 * 
 *         Version: 2025-10-31
 */
package blackjack.game;

/**
 * Purpose: The reponsibility of Card is ...
 *
 * Card is-a ...
 * Card is ...
 */
public class Card
{
	// A card has a suite, and a face/number
	private int suite;
	private int number;

	public Card(int suite, int number)
	{
		this.suite = suite;
		this.number = number;
	}

	public int getSuite()
	{
		return suite;
	}

	public int getNumber()
	{
		return number;
	}

}