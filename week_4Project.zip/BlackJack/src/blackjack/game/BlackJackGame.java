/**
* Lead Author(s):
* @author Andy Garcia
*
* References:
* Morelli, R., & Walde, R. (2016).
* Java, Java, Java: Object-Oriented Problem Solving
* https://open.umn.edu/opentextbooks/textbooks/java-java-java-object-oriented-problem-solving
*
*
* Version: 2025-11-06
*/
package blackjack.game;
import java.awt.*;
import javax.swing.*;


/**
 * Purpose: The reponsibility of BlackJackGame is to create the user-interface for a Game of Black Jack
 *
 * BlackJackGame is-a JFrame
 */
public class BlackJackGame extends JFrame
{
	/**
	 * BlackJackGame.java has-a/has-many serialVersionUID
	 */
	private static final long serialVersionUID = 1L;
	private GameModel model;
	
	public BlackJackGame(GameModel model)
	{
		this.model = model;
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		pack();
		setVisible(true);
		
		// Sets the JFrame layout for the whole game
		this.setLayout(new BorderLayout());
		JPanel DealerPanel = new JPanel(); 				//Create the JPanel for the Dealer
		JLabel DealerLabel = new JLabel("DealerPanel");	//Create and add the component to the JPanel
		DealerPanel.add(DealerLabel);										
		this.add(DealerPanel,  BorderLayout.NORTH);      
		
		
		
		// Set Player Panel
		JPanel playerPanel = new JPanel();
		GridLayout playerLayout = new GridLayout(1,3);
		playerPanel.setLayout(playerLayout);
		
		
		
		
		
		// Panel for Hand 1
		JPanel playerHand1 = new JPanel();
		JLabel hand1Label = new JLabel("First Hand:");
		JButton card1 = new JButton("test");
		JButton card2 = new JButton("test");
		card1.setPreferredSize(new Dimension(150, 200));
		card2.setPreferredSize(new Dimension(150, 200));
		
		playerHand1.add(hand1Label);
		playerHand1.add(card1);
		playerHand1.add(card2);
		
		playerPanel.add(playerHand1);
		
		
		//Panel for hand2
		
		
		
		// Panel for Options
		JPanel options = new JPanel();
		GridLayout optionsGrid = new GridLayout(3, 1);
		options.setLayout(optionsGrid);
		
		JButton HitButton = new JButton("!HIT!");
		JButton SplitButton = new JButton("!SPLIT!");
		JButton StandButton = new JButton("STAND");
		options.add(HitButton);
		options.add(SplitButton);
		options.add(StandButton);
		playerPanel.add(options);
		
		
		this.add(playerPanel, BorderLayout.SOUTH);

	}

	public void playerHitUpdate()
	{
		
	}
	public void dealerHitUpdate()
	{
		
	}
	
	
	/**
	 * Starts the game
	 * @param args not used
	 */
	public static void main(String[] args)
	{
		new BlackJackGame(new GameModel());
	}
	
	
	
}
