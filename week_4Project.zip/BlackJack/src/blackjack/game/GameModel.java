/**
 * Lead Author(s):
 * 
 * @author 0909g; student ID
 * @author Full name; student ID
 *         <<Add additional lead authors here>>
 *
 *         Other Contributors:
 *         Full name; student ID or contact information if not in class
 *         <<Add additional contributors (mentors, tutors, friends) here, with
 *         contact information>>
 *
 *         References:
 *         Morelli, R., & Walde, R. (2016).
 *         Java, Java, Java: Object-Oriented Problem Solving
 *         https://open.umn.edu/opentextbooks/textbooks/java-java-java-object-oriented-problem-solving
 *
 *         <<Add more references here>>
 *
 *         Version: 2025-10-31
 */
package blackjack.game;
import java.util.ArrayList;
import java.util.Random;

/**
 * Purpose: The reponsibility of GameModel is to initialize the Game of Black
 * Jack,
 * with a random deck, with players, and their own first hands
 * 
 * 
 */
public class GameModel
{
	private ArrayList<Card> gameDeck = new ArrayList<Card>();
	public Player Dealer;
	public Player Player1;
	

	public GameModel()
	{
		Random shuffle = new Random();
		// At initialization, the GameModel will create a deck of cards 
		int suite;
		int value;
		suite = shuffle.nextInt(1,5);
		value = shuffle.nextInt(1,14);
		Card firstCard = new Card(suite, value);
		gameDeck.add(firstCard);
		
		
		for (int i = 0; i < 52; i++)
		{
			Card currentCard;
			boolean notUnique = false;
			do
			{
				suite = shuffle.nextInt(1,5);
				value = shuffle.nextInt(1,14);
				currentCard = new Card(suite, value);
				notUnique = false;
				for (int k = 0; k < gameDeck.size(); k++)
				{
					if (gameDeck.get(k).getSuite() == suite && gameDeck.get(k).getNumber() == value)
					{
						notUnique = true;
						break;
					}
				}

			} while (notUnique && gameDeck.size()<52);
			gameDeck.add(currentCard);
		}
	
		Dealer = new Player(gameDeck.removeLast(), gameDeck.removeLast());
		Player1 = new Player(gameDeck.removeLast(), gameDeck.removeLast());
		

	}
	
	/**
	 * Purpose: 
	 * @param i
	 * @param k
	 * @return
	 */


	public boolean is21(Player currentPlayer)
	{
		return false;	
	}

}
