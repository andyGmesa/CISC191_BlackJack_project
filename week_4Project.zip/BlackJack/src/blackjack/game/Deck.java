/**
 * Lead Author(s):
 * 
 * @author 0909g; student ID
 * @author Full name; student ID
 *         <<Add additional lead authors here>>
 *
 *         Other Contributors:
 *         Full name; student ID or contact information if not in class
 *         <<Add additional contributors (mentors, tutors, friends) here, with
 *         contact information>>
 *
 *         References:
 *         Morelli, R., & Walde, R. (2016).
 *         Java, Java, Java: Object-Oriented Problem Solving
 *         https://open.umn.edu/opentextbooks/textbooks/java-java-java-object-oriented-problem-solving
 *
 *         <<Add more references here>>
 *
 *         Version: 2025-10-31
 */
package blackjack.game;

import java.util.Stack;

/**
 * Purpose: The reponsibility of Deck is to simulate a stack of cards,
 * This can be the the full game deck, or the cards held by a player
 *
 * Deck is-a stack
 * Deck is ...
 */
public class Deck
{
	private Stack<Card> cardDeck;
	
	
	public Deck(Deck inputDeck)
	{
		this.cardDeck = inputDeck.cardDeck;
	}

	public void addCard(Card inputCard)
	{
		cardDeck.add(null);
	}

	public Card drawCard()
	{
		Card cardDrawn = cardDeck.pop();
		return cardDrawn;
	}
	
	
	
}
